import React from "react";
import "./donateCSS/Donate.css";

export default function Donate() {
  return (
    <div>
      <img
        src={require("./keep-calm.png")}
        alt="keep-calm"
        className="keep-calm"
      />
    </div>
  );
}
