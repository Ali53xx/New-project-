module.exports = {
  MAP_SECRET_KEY: process.env.MAP_SECRET_KEY
};
