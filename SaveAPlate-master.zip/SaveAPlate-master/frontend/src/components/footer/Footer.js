import React from "react";

export default function Footer() {
  return (
    <footer id="footer">
      <p>Save a Plate</p>
      <p>&copy; 2019</p>
    </footer>
  );
}
