# React Component Hierarchy
________________________________
## Landing Page
* Navbar
* VenderForm
* ClientForm

________________________________

## Feed Page
* Navbar
* SearchComponent
* GoogleLocationComponent
* VendorInfoComponent
* VendorItemComponent

_________________________________

## Vendor Profile
* Navbar
* HoursTimeTableComponent
* VendorInfoComponent
* VendorItemComponent
* VendorFormComponent

_________________________________

## Clent Profile
* displayClientComponent
* VendorLocationComponent
* VendorItemComponent
* ClientFormComponent

_________________________________

## Favorite
* FavoriteComponent -> uses vendor location component
